import{a as t}from"../chunks/entry.6U77Bgqg.js";export{t as start};
