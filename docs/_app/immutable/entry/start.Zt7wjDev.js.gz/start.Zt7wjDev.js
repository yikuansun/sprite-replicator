import{a as t}from"../chunks/entry.DDP344tn.js";export{t as start};
