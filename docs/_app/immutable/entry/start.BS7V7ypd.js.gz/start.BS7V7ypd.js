import{a as t}from"../chunks/entry.CWZ6oj3S.js";export{t as start};
