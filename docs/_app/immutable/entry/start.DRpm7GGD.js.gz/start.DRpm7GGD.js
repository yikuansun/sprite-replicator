import{a as t}from"../chunks/entry.D783JgaG.js";export{t as start};
